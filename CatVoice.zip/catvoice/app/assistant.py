"""
assistant.py
------------
Orchestrates the full pipeline: query -> intent classification ->
knowledge base lookup -> response. This mirrors the real Cat AI Assistant
flow (speech-to-text -> LLM intent parsing -> Helios data lookup ->
text-to-speech), minus the audio I/O layers, which are simulated as
text in/out here to keep the project runnable without external speech
model downloads.
"""

from app.intent_classifier import IntentClassifier
from app.knowledge_base import load_knowledge_base, lookup


class EquipmentAssistant:
    def __init__(self):
        self.classifier = IntentClassifier()
        self.kb = load_knowledge_base()

    def is_ready(self) -> bool:
        return self.classifier.is_ready()

    def handle_query(self, text: str) -> dict:
        intent, confidence = self.classifier.predict(text)

        if intent == "unknown":
            response = ("I'm not confident I understood that. Could you rephrase — "
                        "for example, ask about oil level, faults, maintenance, "
                        "battery, fuel efficiency, or safety status?")
        else:
            response = lookup(intent, self.kb)

        return {
            "query": text,
            "detected_intent": intent,
            "confidence": round(confidence, 3),
            "response": response,
        }
