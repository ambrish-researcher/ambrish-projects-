"""
training_data.py
-----------------
Labeled example queries for training the intent classifier. Each label
corresponds to a key in the knowledge base. In production this stage is
handled by a compact LLM (Caterpillar's real system uses a 4B-parameter
model for intent parsing); here it's a lightweight scikit-learn classifier
trained on hand-labeled examples — a smaller, transparent stand-in for the
same architectural role.
"""

TRAINING_EXAMPLES = [
    # check_oil_level
    ("how do I check the oil level", "check_oil_level"),
    ("what's my engine oil status", "check_oil_level"),
    ("is the oil low", "check_oil_level"),
    ("check oil please", "check_oil_level"),
    ("oil level check", "check_oil_level"),
    ("how much oil is left", "check_oil_level"),
    ("tell me about the oil", "check_oil_level"),
    ("oil status report", "check_oil_level"),
    ("engine oil condition", "check_oil_level"),

    # report_fault
    ("there's a strange noise from the hydraulics", "report_fault"),
    ("report a fault", "report_fault"),
    ("something is wrong with the machine", "report_fault"),
    ("log an issue with hydraulic pressure", "report_fault"),
    ("the machine is not working right", "report_fault"),
    ("i want to report a problem", "report_fault"),
    ("there's an issue with the equipment", "report_fault"),
    ("file a fault report", "report_fault"),
    ("something feels off with this machine", "report_fault"),

    # schedule_maintenance
    ("when is my next maintenance due", "schedule_maintenance"),
    ("schedule a service", "schedule_maintenance"),
    ("book maintenance for this machine", "schedule_maintenance"),
    ("when should I service this excavator", "schedule_maintenance"),
    ("set up a maintenance appointment", "schedule_maintenance"),
    ("when's the next scheduled service", "schedule_maintenance"),
    ("maintenance schedule check", "schedule_maintenance"),
    ("is service due", "schedule_maintenance"),

    # battery_status
    ("what's my battery status", "battery_status"),
    ("check battery voltage", "battery_status"),
    ("is the battery okay", "battery_status"),
    ("battery health check", "battery_status"),
    ("check battery", "battery_status"),
    ("how's the battery doing", "battery_status"),
    ("battery voltage report", "battery_status"),

    # fuel_efficiency
    ("how is my fuel efficiency", "fuel_efficiency"),
    ("check fuel consumption", "fuel_efficiency"),
    ("am I using too much fuel", "fuel_efficiency"),
    ("fuel economy report", "fuel_efficiency"),
    ("how much fuel am I burning", "fuel_efficiency"),
    ("fuel usage status", "fuel_efficiency"),

    # safety_alert
    ("any safety alerts", "safety_alert"),
    ("is it safe to operate", "safety_alert"),
    ("check safety status", "safety_alert"),
    ("are there any warnings", "safety_alert"),
    ("safety check please", "safety_alert"),
    ("is everything safe right now", "safety_alert"),
    ("any active alerts", "safety_alert"),

    # obstacle_detected
    ("is there anything in my path", "obstacle_detected"),
    ("obstacle check", "obstacle_detected"),
    ("is the path clear", "obstacle_detected"),
    ("check for obstacles ahead", "obstacle_detected"),
    ("anything blocking my way", "obstacle_detected"),
    ("clear path check", "obstacle_detected"),

    # greeting
    ("hello", "greeting"),
    ("hi there", "greeting"),
    ("hey assistant", "greeting"),
    ("good morning", "greeting"),
    ("hey there", "greeting"),
    ("hello assistant", "greeting"),
]
