"""
intent_classifier.py
---------------------
Trains and serves a TF-IDF + Logistic Regression intent classifier that
maps a natural-language query (the output of a speech-to-text stage) to
one of the knowledge base's supported intents.

This stands in for the LLM-based intent-parsing stage in Caterpillar's
real Cat AI Assistant pipeline (ASR -> LLM intent parsing -> knowledge
retrieval -> TTS response) — same architectural role, smaller model,
fully transparent and inspectable.
"""

import joblib
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from app.training_data import TRAINING_EXAMPLES

MODEL_PATH = Path(__file__).resolve().parent.parent / "data" / "intent_model.joblib"
# With only ~8-10 examples per intent and 8 total intents, softmax probabilities
# spread thin even on confident, correct predictions (verified empirically: correct
# intent is consistently the argmax even at 0.20-0.35 probability). 0.20 balances
# rejecting true gibberish while not being overconfident about this small model.
CONFIDENCE_THRESHOLD = 0.20


class IntentClassifier:
    def __init__(self):
        self.pipeline = None
        if MODEL_PATH.exists():
            self.pipeline = joblib.load(MODEL_PATH)

    def is_ready(self) -> bool:
        return self.pipeline is not None

    def predict(self, text: str):
        """Returns (intent: str, confidence: float)."""
        if self.pipeline is None:
            raise RuntimeError("Model not trained yet — run train_model.py first")

        probs = self.pipeline.predict_proba([text])[0]
        classes = self.pipeline.classes_
        best_idx = probs.argmax()
        intent, confidence = classes[best_idx], float(probs[best_idx])

        if confidence < CONFIDENCE_THRESHOLD:
            return "unknown", confidence
        return intent, confidence

    @staticmethod
    def train_and_save():
        texts = [t for t, _ in TRAINING_EXAMPLES]
        labels = [l for _, l in TRAINING_EXAMPLES]

        pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1)),
            ("clf", LogisticRegression(max_iter=1000)),
        ])
        pipeline.fit(texts, labels)

        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(pipeline, MODEL_PATH)
        return pipeline
