"""
api.py
------
REST API exposing the equipment assistant, so it could be embedded into
an in-cab display, a fleet-management dashboard, or a mobile app —
mirroring how Cat AI Assistant is embedded across onboard and off-board
Caterpillar digital products.
"""

from fastapi import FastAPI
from pydantic import BaseModel

from app.assistant import EquipmentAssistant

app = FastAPI(
    title="CatVoice",
    description="Voice-style equipment maintenance assistant (intent classification + knowledge retrieval)",
    version="1.0.0",
)

assistant = EquipmentAssistant()


class Query(BaseModel):
    text: str


@app.get("/health")
def health():
    return {"status": "ok", "service": "CatVoice", "model_ready": assistant.is_ready()}


@app.post("/ask")
def ask(query: Query):
    return assistant.handle_query(query.text)
