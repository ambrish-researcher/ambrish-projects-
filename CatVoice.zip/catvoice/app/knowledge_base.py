"""
knowledge_base.py
------------------
A small structured knowledge base of equipment maintenance/troubleshooting
info, standing in for what Caterpillar's Helios unified data platform
provides to the real Cat AI Assistant: trusted, structured machine context
that a voice assistant can retrieve answers from.

In a real system this would be backed by live telemetry + a proper
database; here it's a JSON file to keep the project self-contained and
runnable without external services.
"""

import json
from pathlib import Path

KB_PATH = Path(__file__).resolve().parent.parent / "data" / "knowledge_base.json"


def load_knowledge_base() -> dict:
    with open(KB_PATH, "r") as f:
        return json.load(f)


def lookup(intent: str, kb: dict) -> str:
    entry = kb.get(intent)
    if entry is None:
        return "I don't have information on that yet. Please consult your operator's manual or contact support."
    return entry["response"]
