"""
cli.py
------
Interactive command-line interface simulating voice queries as typed text
(standing in for the ASR/speech-to-text stage). Lets you talk to the
assistant directly.

Usage:
    python cli.py
"""

from app.assistant import EquipmentAssistant


def main():
    assistant = EquipmentAssistant()
    if not assistant.is_ready():
        print("Model not trained yet. Run: python train_model.py")
        return

    print("=== CatVoice Equipment Assistant (type 'quit' to exit) ===")
    print("Try: 'check oil level', 'report a fault', 'when is my next maintenance'\n")

    while True:
        query = input("You: ").strip()
        if query.lower() in ("quit", "exit"):
            break
        if not query:
            continue

        result = assistant.handle_query(query)
        print(f"Assistant [{result['detected_intent']}, "
              f"confidence={result['confidence']}]: {result['response']}\n")


if __name__ == "__main__":
    main()
