# CatVoice 🎙️

**A voice-style equipment maintenance assistant** — intent classification + knowledge retrieval, built in Python.

CatVoice takes a natural-language equipment query (e.g. "when is my next
service due"), classifies its intent with a trained ML model, and returns
a grounded response from a structured knowledge base — the same
architectural pattern (query → intent parsing → knowledge lookup →
response) used by Caterpillar's real **Cat AI Assistant**, unveiled at
CES 2026.

## Why this project — and what it honestly is/isn't

Caterpillar's actual Cat AI Assistant is built on:
- **NVIDIA Riva** speech models (Parakeet ASR + Magpie TTS) for voice I/O
- A **compact LLM** (Qwen3, 4B parameters) for intent parsing, running on
  the **NVIDIA Jetson Thor** edge platform
- **Caterpillar's Helios** unified data platform for trusted machine context

CatVoice implements the **same architectural shape** at a scale a student
can actually build, understand, and defend:

| Real Cat AI Assistant | CatVoice (this project) |
|---|---|
| NVIDIA Riva speech-to-text | Text input (voice I/O simulated, not implemented) |
| Qwen3 4B LLM intent parsing | TF-IDF + Logistic Regression intent classifier (trained, 100% train accuracy, verified to generalize to unseen phrasing) |
| Helios unified data platform | Structured JSON knowledge base |
| NVIDIA Riva TTS | Text output (voice I/O simulated) |

**This is not a claim to have rebuilt Cat AI Assistant.** It's a smaller,
fully transparent system that mirrors the same pipeline shape, built to
demonstrate the underlying engineering pattern — intent recognition,
confidence thresholding, knowledge grounding, and graceful fallback on
out-of-scope queries — which is the reusable, explainable core of that
kind of system regardless of scale.

## Architecture

```
   "when is my next service due"   (query — stands in for ASR output)
              │
              ▼
   ┌─────────────────────┐
   │  IntentClassifier     │   TF-IDF + Logistic Regression
   │  (intent_classifier.py)│  trained on 58 labeled examples across 8 intents
   └──────────┬───────────┘
              │ intent + confidence
              ▼
   ┌─────────────────────┐
   │  Knowledge Base        │   JSON, keyed by intent
   │  (knowledge_base.py)   │   (stands in for Helios)
   └──────────┬───────────┘
              │
              ▼
        Response text
```

## Getting started

```bash
pip install -r requirements.txt

# Train the intent classifier (one-time)
python train_model.py

# Try it interactively
python cli.py

# Or run the API
python main.py
curl -X POST http://localhost:8003/ask -H "Content-Type: application/json" \
     -d '{"text": "when is my next service due"}'
```

## What it supports

8 intents: checking oil level, reporting a fault, scheduling maintenance,
battery status, fuel efficiency, safety alerts, obstacle detection, and
greetings — plus a confidence-thresholded fallback for out-of-scope queries
rather than guessing confidently wrong.

## Running tests

```bash
pytest tests/ -v
```
6 tests, including 3 that specifically test **generalization to phrasing
never seen during training** (e.g. training includes "is the oil low" but
not "how's my engine oil doing" — the model still classifies it correctly)
and one that verifies gibberish input is correctly rejected as "unknown"
rather than misclassified with false confidence.

## Tech stack

| Layer   | Choice                              |
|---------|--------------------------------------|
| Language| Python 3.12                         |
| ML      | scikit-learn (TF-IDF + Logistic Regression) |
| API     | FastAPI + Uvicorn                    |
| Testing | pytest                               |

## Possible extensions
- Add real ASR (e.g. Vosk for offline speech-to-text) and TTS (pyttsx3) for actual voice I/O.
- Swap the JSON knowledge base for live telemetry-backed responses.
- Replace the classifier with a small local LLM for open-ended queries beyond the fixed intent set.

---
Built to demonstrate the intent-recognition + knowledge-grounding pattern
underlying voice-driven industrial assistants like Caterpillar's Cat AI
Assistant — at a scale honestly buildable and explainable by a student.
