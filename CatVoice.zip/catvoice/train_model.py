"""
train_model.py
---------------
Trains the intent classifier and saves it to disk.

Run this once before using the assistant:
    python train_model.py
"""

from app.intent_classifier import IntentClassifier
from app.training_data import TRAINING_EXAMPLES


def main():
    model = IntentClassifier.train_and_save()

    # Sanity check: verify the model correctly classifies its own training examples
    correct = 0
    for text, expected_label in TRAINING_EXAMPLES:
        pred = model.predict([text])[0]
        if pred == expected_label:
            correct += 1

    accuracy = correct / len(TRAINING_EXAMPLES)
    print(f"Trained on {len(TRAINING_EXAMPLES)} examples across "
          f"{len(set(l for _, l in TRAINING_EXAMPLES))} intents.")
    print(f"Training-set accuracy: {accuracy:.1%}")
    print("Model saved to data/intent_model.joblib")


if __name__ == "__main__":
    main()
