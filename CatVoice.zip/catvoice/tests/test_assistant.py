"""
test_assistant.py
------------------
Verifies the intent classifier correctly routes unseen (not just
training-set) queries, and that the assistant correctly falls back to
"unknown" for out-of-scope input rather than guessing confidently wrong.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.assistant import EquipmentAssistant


def test_model_is_ready():
    assistant = EquipmentAssistant()
    assert assistant.is_ready(), "Run train_model.py first"


def test_unseen_oil_query_classified_correctly():
    assistant = EquipmentAssistant()
    result = assistant.handle_query("how's my engine oil doing")  # not in training data verbatim
    assert result["detected_intent"] == "check_oil_level"


def test_unseen_maintenance_query_classified_correctly():
    assistant = EquipmentAssistant()
    result = assistant.handle_query("do I need service soon")
    assert result["detected_intent"] == "schedule_maintenance"


def test_unseen_safety_query_classified_correctly():
    assistant = EquipmentAssistant()
    result = assistant.handle_query("any warnings I should know about")
    assert result["detected_intent"] == "safety_alert"


def test_gibberish_query_falls_back_to_unknown():
    assistant = EquipmentAssistant()
    result = assistant.handle_query("purple elephant banana quantum")
    assert result["detected_intent"] == "unknown"


def test_response_is_never_empty():
    assistant = EquipmentAssistant()
    result = assistant.handle_query("check battery")
    assert len(result["response"]) > 0
