"""
main.py
-------
Entry point for CatVoice's API.

Usage:
    python train_model.py   # one-time: trains the intent classifier
    python main.py           # starts the API on http://localhost:8003
    # or: python cli.py       # interactive text-based testing
"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.api:app", host="0.0.0.0", port=8003, reload=False)
