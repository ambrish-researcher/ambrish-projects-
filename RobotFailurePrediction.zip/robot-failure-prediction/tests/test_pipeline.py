"""
test_pipeline.py
-----------------
Verifies the cleaning step correctly removes injected duplicates/invalid
readings and imputes missing values, and that the trained models produce
sane, above-baseline accuracy.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from src.clean_data import clean
from src.train_models import train_and_evaluate, load_split


def make_dirty_sample():
    df = pd.DataFrame({
        "front_obstacle_distance": [1.0, 1.0, -1.0, 2.0, None],
        "side_obstacle_distance": [1.0, 1.0, 1.0, None, 1.0],
        "velocity": [0.5, 0.5, 0.5, 0.5, 0.5],
        "heading_error": [0, 0, 0, 0, 0],
        "navigation_failure": [0, 0, 1, 0, 1],
    })
    return df


def test_clean_removes_duplicates():
    df = make_dirty_sample()
    cleaned = clean(df)
    assert len(cleaned) < len(df)


def test_clean_removes_negative_distances():
    df = make_dirty_sample()
    cleaned = clean(df)
    assert (cleaned["front_obstacle_distance"] >= 0).all()


def test_clean_imputes_missing_values():
    df = make_dirty_sample()
    cleaned = clean(df)
    assert cleaned["side_obstacle_distance"].isna().sum() == 0


def test_models_beat_random_baseline():
    result = train_and_evaluate()
    # A random baseline on a moderately imbalanced binary task should be well
    # below 70% — both models should clear that bar comfortably if the
    # pipeline actually learned a real signal.
    assert result["log_reg_accuracy"] > 0.70
    assert result["rf_accuracy"] > 0.70


def test_top_feature_is_front_obstacle_distance():
    result = train_and_evaluate()
    assert result["top_feature"] == "front_obstacle_distance"
