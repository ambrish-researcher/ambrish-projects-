# Robot Navigation Failure Prediction (ML Pipeline)

**Predicting the breakdown before it happens.**

An end-to-end ML pipeline that predicts robot navigation failures from
sensor data — extending a ROS navigation project into a full
data-to-model workflow: raw telemetry → cleaning → model training →
evaluation.

## ⚠️ Important note on the numbers below

This code implements the same methodology described on the resume (clean
a sensor log, train Logistic Regression vs. Random Forest on an 80/20
stratified split, identify the strongest failure predictor). Run fresh,
on synthetic data with a fixed seed, it produces:

- Logistic Regression accuracy: **0.866**
- Random Forest accuracy: **0.870**
- Strongest predictor: **front_obstacle_distance**

These are close to, but not identical to, the original resume figures
(0.849 / 0.866) — which is expected, since exact reproduction depends on
the original dataset and random seed. **If you have your original
notebook/script and data, use those real numbers — they're more valuable
than anything regenerated here.** This code is provided as a working,
testable implementation of the same pipeline in case the original was
lost, and as something you can actually run and explain.

## Pipeline

```
generate_sensor_log.py  →  clean_data.py  →  train_models.py
   (synthetic log,           (dedupe,           (LogReg vs
    or replace with            remove invalid,    RandomForest,
    your real log)              impute missing)    feature importance)
```

## Getting started

```bash
pip install -r requirements.txt

# 1. Generate a synthetic sensor log (skip if you have your own real log —
#    just place it at data/sensor_log.csv with the same column names)
python src/generate_sensor_log.py

# 2. Clean it
python src/clean_data.py

# 3. Train and compare models
python src/train_models.py
```

## Data cleaning — documented reasoning

| Step | Why |
|---|---|
| Remove duplicate rows | Duplicated readings can leak across train/test and inflate reported accuracy |
| Remove negative distances | Physically impossible for a distance sensor — these are faults, not real readings |
| Median-impute missing values | Robust to the skew/outliers typical of distance sensor data (occasional very large "clear path" readings) |

## Running tests

```bash
pytest tests/ -v
```
5 tests: verifies cleaning actually removes injected duplicates/invalid
readings and imputes missing values correctly, and that both models beat
a random baseline and correctly identify the top failure predictor.

## Tech stack

Python, pandas, NumPy, scikit-learn (LogisticRegression, RandomForestClassifier), pytest
