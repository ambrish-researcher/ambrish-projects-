"""
clean_data.py
-------------
Cleans the raw sensor log: removes duplicate rows and physically invalid
readings, and imputes missing values — each step documented with the
reasoning behind it, matching the "documented, justified reasoning"
claim on the resume.
"""

import pandas as pd
from pathlib import Path

RAW_PATH = Path(__file__).resolve().parent.parent / "data" / "sensor_log.csv"
CLEAN_PATH = Path(__file__).resolve().parent.parent / "data" / "sensor_log_clean.csv"


def clean(df: pd.DataFrame) -> pd.DataFrame:
    initial_rows = len(df)

    # 1. Remove exact duplicate rows.
    # Reasoning: duplicate sensor readings inflate whichever class they belong
    # to and bias the train/test split — a duplicated failure row could leak
    # into both train and test, artificially boosting reported accuracy.
    df = df.drop_duplicates()
    after_dedup = len(df)

    # 2. Remove physically invalid readings.
    # Reasoning: an ultrasonic/LiDAR-style distance sensor cannot report a
    # negative distance — these are sensor faults or logging errors, not
    # real measurements, and including them would teach the model a
    # relationship that doesn't exist in the physical world.
    df = df[df["front_obstacle_distance"] >= 0]
    df = df[df["side_obstacle_distance"].isna() | (df["side_obstacle_distance"] >= 0)]
    after_invalid_removal = len(df)

    # 3. Impute missing values with the column median.
    # Reasoning: median is robust to the outliers/skew typical of distance
    # sensor data (occasional very large "no obstacle in range" readings),
    # unlike the mean which those outliers would pull upward.
    median_side_distance = df["side_obstacle_distance"].median()
    df["side_obstacle_distance"] = df["side_obstacle_distance"].fillna(median_side_distance)

    print(f"Initial rows: {initial_rows}")
    print(f"After removing duplicates: {after_dedup} (-{initial_rows - after_dedup})")
    print(f"After removing invalid readings: {after_invalid_removal} (-{after_dedup - after_invalid_removal})")
    print(f"Imputed side_obstacle_distance missing values with median: {median_side_distance:.3f}")

    return df.reset_index(drop=True)


def main():
    df = pd.read_csv(RAW_PATH)
    clean_df = clean(df)
    clean_df.to_csv(CLEAN_PATH, index=False)
    print(f"Clean data saved to {CLEAN_PATH}")


if __name__ == "__main__":
    main()
