"""
train_models.py
----------------
Trains and compares Logistic Regression vs. Random Forest on the cleaned
sensor log to predict navigation failure, using an 80/20 stratified split
(stratified so both train and test preserve the same failure/success
ratio — important here since failures are the minority class).

Also reports feature importance to identify the strongest failure
predictor, matching the resume claim.
"""

import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

CLEAN_PATH = Path(__file__).resolve().parent.parent / "data" / "sensor_log_clean.csv"
FEATURES = ["front_obstacle_distance", "side_obstacle_distance", "velocity", "heading_error"]
TARGET = "navigation_failure"


def load_split():
    df = pd.read_csv(CLEAN_PATH)
    X = df[FEATURES]
    y = df[TARGET]
    return train_test_split(X, y, test_size=0.2, stratify=y, random_state=7)


def train_and_evaluate():
    X_train, X_test, y_train, y_test = load_split()

    log_reg = LogisticRegression(max_iter=1000)
    log_reg.fit(X_train, y_train)
    log_reg_acc = accuracy_score(y_test, log_reg.predict(X_test))

    rf = RandomForestClassifier(n_estimators=200, random_state=7)
    rf.fit(X_train, y_train)
    rf_acc = accuracy_score(y_test, rf.predict(X_test))

    # Feature importance from the Random Forest (more directly interpretable
    # for "which feature matters most" than logistic regression coefficients,
    # which are scale-dependent).
    importances = pd.Series(rf.feature_importances_, index=FEATURES).sort_values(ascending=False)

    print(f"Logistic Regression accuracy: {log_reg_acc:.3f}")
    print(f"Random Forest accuracy: {rf_acc:.3f}")
    print("\nFeature importance (Random Forest):")
    for feature, importance in importances.items():
        print(f"  {feature}: {importance:.3f}")
    print(f"\nStrongest failure predictor: {importances.index[0]}")

    return {
        "log_reg_accuracy": log_reg_acc,
        "rf_accuracy": rf_acc,
        "top_feature": importances.index[0],
    }


if __name__ == "__main__":
    train_and_evaluate()
