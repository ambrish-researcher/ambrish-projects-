"""
generate_sensor_log.py
-----------------------
Generates a synthetic robot navigation sensor log that mimics real ROS
telemetry: front/side obstacle distances, velocity, heading error, and a
binary navigation_failure label — deliberately injected with duplicate
rows and a few physically invalid readings (negative distances, out-of-
range sensor values), so the cleaning step in clean_data.py has real work
to do rather than operating on already-perfect data.

Run this first if you don't have your own original sensor log:
    python src/generate_sensor_log.py
"""

import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(7)
N_ROWS = 1250  # >1,200 rows, matching the resume claim
OUT_PATH = Path(__file__).resolve().parent.parent / "data" / "sensor_log.csv"


def generate():
    n = N_ROWS

    # Failure is more likely when front obstacle distance is small and velocity is high
    front_obstacle_distance = np.abs(RNG.normal(1.5, 0.8, n))  # meters
    side_obstacle_distance = np.abs(RNG.normal(1.2, 0.6, n))
    velocity = np.abs(RNG.normal(0.5, 0.2, n))  # m/s
    heading_error = RNG.normal(0, 15, n)  # degrees

    # Failure probability increases as front distance shrinks and velocity rises
    risk_score = (2.0 / (front_obstacle_distance + 0.1)) * velocity
    failure_prob = 1 / (1 + np.exp(-(risk_score - 3)))  # logistic squashing
    navigation_failure = (RNG.random(n) < failure_prob).astype(int)

    df = pd.DataFrame({
        "front_obstacle_distance": front_obstacle_distance,
        "side_obstacle_distance": side_obstacle_distance,
        "velocity": velocity,
        "heading_error": heading_error,
        "navigation_failure": navigation_failure,
    })

    # Inject data-quality issues for the cleaning step to handle
    dup_idx = RNG.choice(df.index, size=30, replace=False)
    df = pd.concat([df, df.loc[dup_idx]], ignore_index=True)  # duplicate rows

    invalid_idx = RNG.choice(df.index, size=15, replace=False)
    df.loc[invalid_idx, "front_obstacle_distance"] = -1.0  # physically invalid

    missing_idx = RNG.choice(df.index, size=20, replace=False)
    df.loc[missing_idx, "side_obstacle_distance"] = np.nan  # missing values

    df = df.sample(frac=1, random_state=7).reset_index(drop=True)  # shuffle

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_PATH, index=False)
    print(f"Generated {len(df)} rows -> {OUT_PATH}")
    print(f"  Duplicates injected: {len(dup_idx)}")
    print(f"  Invalid readings injected: {len(invalid_idx)}")
    print(f"  Missing values injected: {len(missing_idx)}")


if __name__ == "__main__":
    generate()
