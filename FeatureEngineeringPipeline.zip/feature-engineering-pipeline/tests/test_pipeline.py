"""
test_pipeline.py
-----------------
Verifies the naive and vectorized feature computations produce the same
result (correctness matters as much as speed), and that the experiment
runs end-to-end and reports metrics for both conditions.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from src.benchmark import naive_feature_computation, vectorized_feature_computation


def make_sample_df():
    return pd.DataFrame({
        "user_id": [1, 1, 2, 2, 2, 3],
        "purchase_amount": [10.0, 20.0, 0.0, 5.0, 15.0, 100.0],
    })


def test_naive_and_vectorized_agree():
    df = make_sample_df()
    naive_result = naive_feature_computation(df)
    vectorized_result = vectorized_feature_computation(df)

    for user_id, naive_value in naive_result.items():
        assert abs(naive_value - vectorized_result[user_id]) < 1e-9, (
            f"Mismatch for user {user_id}: naive={naive_value}, "
            f"vectorized={vectorized_result[user_id]}"
        )


def test_vectorized_computation_correctness():
    df = make_sample_df()
    result = vectorized_feature_computation(df)
    assert abs(result[1] - 15.0) < 1e-9   # (10+20)/2
    assert abs(result[2] - 20/3) < 1e-9   # (0+5+15)/3
    assert abs(result[3] - 100.0) < 1e-9  # single value
