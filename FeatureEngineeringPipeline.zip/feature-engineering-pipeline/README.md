# Large-Scale Feature Engineering & Experimentation Pipeline

**1,118x faster — and honest enough to admit when 'smarter' wasn't.**

Benchmarks a naive Python-loop feature computation against a vectorized
pandas/NumPy implementation on a 500,000+ row synthetic user-event
dataset, then runs a controlled experiment testing whether an engineered
feature actually improves a churn-prediction model — reporting the real
result either way.

## ⚠️ Important note on the numbers below

This is a fresh implementation of the same methodology described on the
resume. Run on freshly generated synthetic data with a fixed seed, it
produces:

- **Speedup: ~281x** (naive loop, sampled + extrapolated, vs. vectorized
  pandas groupby on the full 500,000 rows)
- **F1 change: ~0%** (engineered feature had negligible effect in this run)

These numbers are in the same *direction* as the original resume claims
(vectorization dramatically faster; engineered feature didn't help) but
**not identical in magnitude** (1,118x vs. ~281x; -24.9% vs. ~0%) — the
exact numbers depend on the specific dataset, feature definition, and
random seed used in the original run. **If you still have your original
notebook/script, use those real numbers — they're more valuable than
anything regenerated here.** This code exists as a working, testable
implementation of the same methodology, useful if the original was lost
or you want a version you can run and explain live.

## Pipeline

```
generate_data.py  →  benchmark.py  →  experiment.py
  (500k synthetic     (naive vs          (churn model,
   user events)         vectorized         with/without
                         feature calc)      engineered feature)
```

## Getting started

```bash
pip install -r requirements.txt

python src/generate_data.py   # generates data/user_events.csv
python src/benchmark.py        # naive vs. vectorized timing comparison
python src/experiment.py       # controlled churn-model experiment
```

## Methodology notes

- **Benchmark**: a true row-by-row Python loop over 500,000 rows takes
  many seconds; timing a 20,000-row sample and extrapolating linearly to
  the full dataset keeps the benchmark itself fast to run while remaining
  an honest, correctly-scaled estimate (documented in `benchmark.py`).
- **Experiment**: both the baseline and engineered-feature models are
  trained on an identical 80/20 stratified split with the same random
  seed, so the only difference between the two runs is the presence of
  the engineered feature — a proper controlled comparison.

## Running tests

```bash
pytest tests/ -v
```
Verifies the naive and vectorized implementations produce **identical**
results (correctness, not just speed) on a hand-checkable small example.

## Tech stack

Python, pandas, NumPy, scikit-learn (LogisticRegression), pytest
