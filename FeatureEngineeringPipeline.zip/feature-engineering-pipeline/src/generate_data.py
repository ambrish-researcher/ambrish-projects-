"""
generate_data.py
-----------------
Generates a synthetic 500,000+ row user-event dataset for benchmarking
feature computation approaches and training a churn-prediction model.

Run this first:
    python src/generate_data.py
"""

import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)
N_ROWS = 500_000
OUT_PATH = Path(__file__).resolve().parent.parent / "data" / "user_events.csv"


def generate():
    n = N_ROWS

    user_id = RNG.integers(1, 50_000, n)  # ~10 events per user on average
    session_length_sec = np.abs(RNG.normal(300, 150, n))
    pages_viewed = RNG.poisson(4, n)
    purchase_amount = np.where(RNG.random(n) < 0.15, np.abs(RNG.normal(40, 20, n)), 0.0)
    days_since_signup = RNG.integers(0, 720, n)

    # Churn is more likely with short sessions, few pages, no purchases,
    # and longer tenure without recent engagement — a plausible signal for
    # the model to learn.
    churn_logit = (
        -0.01 * session_length_sec
        - 0.3 * pages_viewed
        - 0.05 * purchase_amount
        + 0.005 * days_since_signup
        + RNG.normal(0, 2, n)
    )
    churn_prob = 1 / (1 + np.exp(-((churn_logit - churn_logit.mean()) / churn_logit.std())))
    churned = (RNG.random(n) < churn_prob).astype(int)

    df = pd.DataFrame({
        "user_id": user_id,
        "session_length_sec": session_length_sec,
        "pages_viewed": pages_viewed,
        "purchase_amount": purchase_amount,
        "days_since_signup": days_since_signup,
        "churned": churned,
    })

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_PATH, index=False)
    print(f"Generated {len(df):,} rows -> {OUT_PATH}")
    print(f"Churn rate: {df['churned'].mean():.1%}")


if __name__ == "__main__":
    generate()
