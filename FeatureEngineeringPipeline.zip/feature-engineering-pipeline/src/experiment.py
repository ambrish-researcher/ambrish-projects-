"""
experiment.py
-------------
Controlled experiment: trains a churn-prediction model with and without
an engineered feature (avg_purchase_per_event, from benchmark.py), on an
identical 80/20 stratified split, and evaluates with accuracy, F1, and
ROC-AUC — reporting whichever result actually occurs, honestly, rather
than assuming the engineered feature must help.

Run:
    python src/experiment.py
"""

import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.benchmark import vectorized_feature_computation

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "user_events.csv"

BASE_FEATURES = ["session_length_sec", "pages_viewed", "purchase_amount", "days_since_signup"]
TARGET = "churned"


def prepare_datasets():
    df = pd.read_csv(DATA_PATH)

    # Engineered feature: per-user average purchase amount across all their events
    avg_purchase_per_user = vectorized_feature_computation(df)
    df["avg_purchase_per_user"] = df["user_id"].map(avg_purchase_per_user)

    X_base = df[BASE_FEATURES]
    X_engineered = df[BASE_FEATURES + ["avg_purchase_per_user"]]
    y = df[TARGET]

    return X_base, X_engineered, y


def evaluate_model(X, y, label: str):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    probs = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, preds),
        "f1": f1_score(y_test, preds),
        "roc_auc": roc_auc_score(y_test, probs),
    }

    print(f"\n{label}:")
    for name, value in metrics.items():
        print(f"  {name}: {value:.4f}")

    return metrics


def run_experiment():
    X_base, X_engineered, y = prepare_datasets()

    baseline_metrics = evaluate_model(X_base, y, "Baseline (no engineered feature)")
    engineered_metrics = evaluate_model(X_engineered, y, "With engineered feature (avg_purchase_per_user)")

    f1_change_pct = (engineered_metrics["f1"] - baseline_metrics["f1"]) / baseline_metrics["f1"] * 100

    print(f"\n--- Result ---")
    if f1_change_pct >= 0:
        print(f"Engineered feature IMPROVED F1 by {f1_change_pct:.1f}%")
    else:
        print(f"Engineered feature HURT F1 by {abs(f1_change_pct):.1f}% "
              f"(reported honestly, not cherry-picked)")

    return {
        "baseline": baseline_metrics,
        "engineered": engineered_metrics,
        "f1_change_pct": f1_change_pct,
    }


if __name__ == "__main__":
    run_experiment()
