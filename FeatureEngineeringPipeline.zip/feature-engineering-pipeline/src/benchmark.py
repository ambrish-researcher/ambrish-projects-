"""
benchmark.py
------------
Benchmarks a naive Python-loop feature computation against a vectorized
pandas/NumPy implementation, computing a per-user engineered feature
(average purchase amount per session, a plausible churn-prediction
feature) both ways and timing each.

Run:
    python src/benchmark.py
"""

import time
import pandas as pd
import numpy as np
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "user_events.csv"

# For the naive loop, use a manageable sample — a true row-by-row Python
# loop over 500,000 rows takes tens of seconds; timing a smaller sample and
# extrapolating linearly (as the resume claim does) keeps the benchmark
# itself fast to run while still being an honest, correctly-scaled estimate.
NAIVE_SAMPLE_SIZE = 20_000


def naive_feature_computation(df: pd.DataFrame) -> dict:
    """Row-by-row Python loop: compute avg purchase per session, per user."""
    user_totals = {}
    user_counts = {}
    for _, row in df.iterrows():
        uid = row["user_id"]
        user_totals[uid] = user_totals.get(uid, 0.0) + row["purchase_amount"]
        user_counts[uid] = user_counts.get(uid, 0) + 1

    avg_purchase = {uid: user_totals[uid] / user_counts[uid] for uid in user_totals}
    return avg_purchase


def vectorized_feature_computation(df: pd.DataFrame) -> pd.Series:
    """Vectorized pandas groupby — no explicit Python-level row loop."""
    return df.groupby("user_id")["purchase_amount"].mean()


def run_benchmark():
    df = pd.read_csv(DATA_PATH)
    sample = df.sample(n=NAIVE_SAMPLE_SIZE, random_state=42).reset_index(drop=True)

    start = time.perf_counter()
    naive_feature_computation(sample)
    naive_time_sample = time.perf_counter() - start

    start = time.perf_counter()
    vectorized_feature_computation(df)  # run on full dataset — this is the whole point
    vectorized_time_full = time.perf_counter() - start

    # Extrapolate naive time linearly to full dataset size for a fair comparison
    scale_factor = len(df) / NAIVE_SAMPLE_SIZE
    naive_time_estimated_full = naive_time_sample * scale_factor

    speedup = naive_time_estimated_full / vectorized_time_full

    print(f"Naive loop, {NAIVE_SAMPLE_SIZE:,}-row sample: {naive_time_sample:.4f}s")
    print(f"Naive loop, estimated for {len(df):,} rows: {naive_time_estimated_full:.2f}s")
    print(f"Vectorized pandas/NumPy, full {len(df):,} rows: {vectorized_time_full:.4f}s")
    print(f"Speedup: {speedup:,.0f}x")

    return {
        "naive_time_sample": naive_time_sample,
        "naive_time_estimated_full": naive_time_estimated_full,
        "vectorized_time_full": vectorized_time_full,
        "speedup": speedup,
    }


if __name__ == "__main__":
    run_benchmark()
